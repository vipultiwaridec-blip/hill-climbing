/* Tiny WebAudio synth: engine drone + arcade SFX. No assets required. */

export class SoundFX {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  engineGain: GainNode | null = null;
  oscA: OscillatorNode | null = null;
  oscB: OscillatorNode | null = null;
  filter: BiquadFilterNode | null = null;
  noiseBuf: AudioBuffer | null = null;
  muted = false;
  started = false;

  init() {
    if (this.started) return;
    try {
      const Ctor: typeof AudioContext =
        (window as unknown as { AudioContext: typeof AudioContext; webkitAudioContext?: typeof AudioContext })
          .AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      const ctx = new Ctor();
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.6;
      this.master.connect(ctx.destination);

      // engine chain
      const g = ctx.createGain();
      g.gain.value = 0;
      const f = ctx.createBiquadFilter();
      f.type = "lowpass";
      f.frequency.value = 900;
      f.Q.value = 6;
      const oa = ctx.createOscillator();
      oa.type = "sawtooth";
      oa.frequency.value = 60;
      const ob = ctx.createOscillator();
      ob.type = "square";
      ob.frequency.value = 61;
      oa.connect(f);
      ob.connect(f);
      f.connect(g);
      g.connect(this.master);
      oa.start();
      ob.start();
      this.engineGain = g;
      this.oscA = oa;
      this.oscB = ob;
      this.filter = f;

      // noise buffer for impacts / wind
      const len = Math.floor(ctx.sampleRate * 1.2);
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.noiseBuf = buf;
      this.started = true;
    } catch {
      this.started = false;
    }
  }

  resume() {
    this.init();
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.6, this.ctx.currentTime, 0.03);
    }
  }

  private now(): number {
    return this.ctx ? this.ctx.currentTime : 0;
  }

  /** Engine drone driven by wheel speed + throttle. */
  engine(speed01: number, throttle: number, grounded: boolean) {
    if (!this.ctx || !this.engineGain || !this.oscA || !this.oscB || !this.filter) return;
    const t = this.now();
    const freq = 52 + speed01 * 205 + (throttle > 0 ? 10 : 0);
    this.oscA.frequency.setTargetAtTime(freq, t, 0.06);
    this.oscB.frequency.setTargetAtTime(freq * 1.51, t, 0.06);
    const vol = (grounded ? 0.1 : 0.045) + throttle * 0.075;
    this.engineGain.gain.setTargetAtTime(vol, t, 0.08);
    this.filter.frequency.setTargetAtTime(500 + speed01 * 1500 + throttle * 400, t, 0.1);
  }

  silentEngine() {
    if (!this.ctx || !this.engineGain) return;
    this.engineGain.gain.setTargetAtTime(0, this.now(), 0.08);
  }

  private blip(freq: number, dur: number, type: OscillatorType, vol: number, delay = 0, slide = 0) {
    if (!this.ctx || !this.master) return;
    const t = this.now() + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(dur: number, vol: number, freqFrom: number, freqTo: number, q = 1) {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const t = this.now();
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.Q.value = q;
    f.frequency.setValueAtTime(freqFrom, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(60, freqTo), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t);
    src.stop(t + dur + 0.02);
  }

  coin(pitchStep = 0) {
    const f = 880 * Math.pow(1.0595, pitchStep * 2);
    this.blip(f, 0.09, "square", 0.16);
    this.blip(f * 1.5, 0.12, "square", 0.11, 0.06);
  }

  flip() {
    this.blip(523, 0.1, "triangle", 0.18);
    this.blip(659, 0.1, "triangle", 0.18, 0.08);
    this.blip(988, 0.2, "triangle", 0.2, 0.16);
  }

  land(power: number) {
    const p = Math.max(0.15, Math.min(1, power));
    this.noise(0.22 + p * 0.2, 0.12 + p * 0.3, 900 + p * 900, 70, 0.7);
    this.blip(90 + p * 40, 0.16, "sine", 0.12 + p * 0.2, 0, -40);
  }

  crash() {
    this.noise(0.7, 0.45, 1400, 60, 0.6);
    this.blip(220, 0.6, "sawtooth", 0.22, 0, -170);
    this.blip(160, 0.7, "square", 0.14, 0.05, -120);
  }

  boost() {
    this.noise(0.5, 0.28, 400, 2600, 2);
    this.blip(180, 0.35, "sawtooth", 0.12, 0, 420);
  }

  pickupFuel() {
    this.blip(392, 0.12, "square", 0.16);
    this.blip(587, 0.16, "square", 0.16, 0.09);
    this.blip(784, 0.22, "square", 0.14, 0.18);
  }

  uiClick() {
    this.blip(660, 0.07, "square", 0.12);
    this.blip(990, 0.09, "square", 0.09, 0.05);
  }

  gameOver() {
    this.blip(440, 0.18, "triangle", 0.18);
    this.blip(330, 0.2, "triangle", 0.18, 0.16);
    this.blip(247, 0.4, "triangle", 0.18, 0.34);
  }

  skid() {
    this.noise(0.1, 0.05, 2200, 900, 3);
  }

  levelUp() {
    this.blip(660, 0.3, "triangle", 0.14);
    this.blip(880, 0.3, "triangle", 0.12, 0.05);
  }
}

export const sfx = new SoundFX();
