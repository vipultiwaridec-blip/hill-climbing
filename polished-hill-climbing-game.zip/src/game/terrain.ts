/* Deterministic terrain + noise helpers for Hill Rush */

export function hash1(n: number, seed = 0): number {
  let x = Math.sin(n * 127.1 + seed * 311.7) * 43758.5453123;
  return x - Math.floor(x);
}

export function rand2(a: number, b: number, seed = 0): number {
  const h = Math.sin(a * 12.9898 + b * 78.233 + seed * 43.123) * 43758.5453123;
  return h - Math.floor(h);
}

/** Smooth (cubic) 1D value noise in [0,1] */
export function noise1(x: number, seed = 0): number {
  const i = Math.floor(x);
  const f = x - i;
  const a = hash1(i, seed);
  const b = hash1(i + 1, seed);
  const u = f * f * (3 - 2 * f);
  return a + (b - a) * u;
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

export function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}

/**
 * Endless procedural hill world.
 * y grows downward, so ground height is measured as "how far down".
 */
export class Terrain {
  seed: number;

  constructor(seed: number) {
    this.seed = seed;
  }

  /** Raw fractal height for a world x (before the gentle-start blend). */
  private raw(x: number, difficulty: number): number {
    const s = this.seed;
    const xf = x / 20; // work in "meters" for nicer frequencies
    let h = 0;
    h += noise1(xf / 46, s) * 210;
    h += noise1(xf / 19 + 11.3, s + 7) * 96;
    h += noise1(xf / 7.5 + 31.7, s + 19) * 34;
    h += noise1(xf / 3.1 + 63.1, s + 43) * 8 * (0.4 + difficulty * 0.9);
    // A slow swell so the world breathes between valleys and ridges.
    h += Math.sin(xf / 26 + hash1(3, s) * 10) * 90 * difficulty;
    return h;
  }

  /** World-space ground y at a given world x. */
  height(x: number): number {
    // difficulty ramps from 0.35 -> 1.4 over the first ~7000px
    const difficulty = 0.35 + 1.05 * smoothstep(400, 7000, x);
    const amp = 0.55 + 0.72 * smoothstep(200, 3000, x);
    const raw = this.raw(x, difficulty) * amp;
    // Carve a calm, nearly flat launch pad so the first seconds feel heroic.
    const startBlend = smoothstep(340, 1500, x);
    const flat = -Math.sin(Math.max(0, x) / 190) * 6;
    return lerp(flat, raw, startBlend) - 120;
  }

  /** Ground slope (dy/dx). */
  slope(x: number): number {
    const d = 2.5;
    return (this.height(x + d) - this.height(x - d)) / (d * 2);
  }

  /** Unit ground normal pointing up out of the hill. */
  normal(x: number, out: { x: number; y: number }): void {
    const t = Math.atan(this.slope(x));
    // tangent = (cos, sin), normal points up (-y-ish)
    out.x = Math.sin(t);
    out.y = -Math.cos(t);
  }

  /** Unit tangent pointing "forward" (positive x direction along the hill). */
  tangent(x: number, out: { x: number; y: number }): void {
    const t = Math.atan(this.slope(x));
    out.x = Math.cos(t);
    out.y = Math.sin(t);
  }
}

/** Coins / fuel cans are generated in fixed 220px chunks from a hash stream. */
export interface Pickup {
  x: number;
  y: number;
  kind: "coin" | "fuel";
  taken: boolean;
  spin: number;
}

export const CHUNK = 220;

export function chunkPickups(index: number, terrain: Terrain, seed: number): Pickup[] {
  const out: Pickup[] = [];
  const baseX = index * CHUNK;
  if (baseX < 900) return out;

  const r = rand2(index, 1, seed);
  const r2 = rand2(index, 2, seed);
  const fuelEvery = 8;
  const isFuel = index % fuelEvery === 3 && rand2(index, 5, seed) < 0.8;

  if (isFuel) {
    const x = baseX + 60 + r * 90;
    out.push({ x, y: terrain.height(x) - 34, kind: "fuel", taken: false, spin: 0 });
    return out;
  }

  if (r < 0.52) {
    const count = 3 + Math.floor(r2 * 4);
    const spacing = 42;
    const start = baseX + 40 + r2 * 70;
    const arcRise = 26 + rand2(index, 7, seed) * 66;
    for (let i = 0; i < count; i++) {
      const x = start + i * spacing;
      const t = count > 1 ? i / (count - 1) : 0.5;
      const lift = Math.sin(t * Math.PI) * arcRise;
      out.push({ x, y: terrain.height(x) - 40 - lift, kind: "coin", taken: false, spin: i * 0.7 });
    }
  }
  return out;
}
