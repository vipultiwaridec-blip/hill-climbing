import { sfx } from "./audio";
import {
  CHUNK,
  chunkPickups,
  clamp,
  hash1,
  lerp,
  type Pickup,
  smoothstep,
  Terrain,
} from "./terrain";

/* roundRect is not universal yet — tiny polyfill keeps the art code clean. */
if (typeof CanvasRenderingContext2D !== "undefined" && !CanvasRenderingContext2D.prototype.roundRect) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (CanvasRenderingContext2D.prototype as any).roundRect = function (
    this: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number | number[] = 0
  ) {
    const rad = Math.min(typeof r === "number" ? r : r[0], Math.abs(w) / 2, Math.abs(h) / 2);
    this.moveTo(x + rad, y);
    this.arcTo(x + w, y, x + w, y + h, rad);
    this.arcTo(x + w, y + h, x, y + h, rad);
    this.arcTo(x, y + h, x, y, rad);
    this.arcTo(x, y, x + w, y, rad);
    this.closePath();
  };
}

export type GameState = "menu" | "playing" | "paused" | "gameover";

export interface HudState {
  score: number;
  coins: number;
  fuel: number;
  boost: number;
  speed: number;
  distance: number;
  combo: number;
  flips: number;
  airTime: number;
  boosting: boolean;
  state: GameState;
}

export interface RunResult {
  score: number;
  distance: number;
  coins: number;
  flips: number;
  airTime: number;
  cause: string;
  causeIcon: string;
}

export interface InputState {
  gas: boolean;
  brake: boolean;
  boost: boolean;
  jump: boolean;
}

interface Wheel {
  lx: number;
  ly: number;
  wx: number;
  wy: number;
  cx: number;
  cy: number;
  contact: boolean;
  pen: number;
  prevPen: number;
  spin: number;
  slip: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  rot: number;
  vr: number;
  drag: number;
  grav: number;
  c: string;
  kind: "soft" | "square" | "ring";
}

interface FloatText {
  x: number;
  y: number;
  vy: number;
  life: number;
  max: number;
  text: string;
  color: string;
  size: number;
}

type RGB = [number, number, number];
interface Palette {
  skyTop: RGB;
  skyMid: RGB;
  skyBot: RGB;
  sun: RGB;
  far: RGB;
  mid: RGB;
  near: RGB;
  grass: RGB;
  grassHi: RGB;
  soil: RGB;
  soilDeep: RGB;
  rock: RGB;
}

const DUSK: Palette = {
  skyTop: [38, 18, 66],
  skyMid: [148, 48, 108],
  skyBot: [255, 152, 88],
  sun: [255, 232, 184],
  far: [96, 52, 112],
  mid: [62, 32, 82],
  near: [40, 22, 52],
  grass: [86, 146, 88],
  grassHi: [158, 206, 116],
  soil: [76, 50, 60],
  soilDeep: [38, 24, 32],
  rock: [104, 86, 96],
};

const NIGHT: Palette = {
  skyTop: [8, 9, 26],
  skyMid: [26, 22, 66],
  skyBot: [92, 56, 108],
  sun: [226, 214, 255],
  far: [44, 40, 88],
  mid: [28, 24, 58],
  near: [16, 14, 36],
  grass: [44, 92, 82],
  grassHi: [96, 156, 124],
  soil: [42, 34, 48],
  soilDeep: [18, 14, 24],
  rock: [74, 66, 78],
};

const G = 1650;
const FIXED = 1 / 150;
const REST_LEN = 22;
const WHEEL_R = 15;
const SPRING_K = 9200;
const SPRING_C = 78;
const BODY_K = 17000;
const BODY_C = 150;
const INERTIA = 760;
const DRIVE = 1560;
const MAX_SPEED = 1250;
const MAX_REVERSE = 550;
const SPEED_REF = 900;
const MU = 1.35;
const AIR_ACC = 40;
const AIR_AV_CAP = 10.5;
const GROUND_TORQUE = 1.5;
const FUEL_MAX = 100;
const FUEL_RATE = 2.05;
const COST_DRAG = 0.0007;

const ANCHORS = [
  { x: -31, y: 7 },
  { x: 31, y: 7 },
];

const BODY_PTS = [
  { x: -34, y: -6, r: 6 },
  { x: 0, y: -16, r: 7 },
  { x: 34, y: -6, r: 6 },
  { x: -16, y: -17, r: 6 },
  { x: 18, y: -15, r: 6 },
  { x: 0, y: 14, r: 8 },
];

const HEAD = { x: -12, y: -33 };

function mix(a: RGB, b: RGB, t: number): RGB {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
}
function rgba(c: RGB, a = 1): string {
  return `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
}

export interface EngineCallbacks {
  onHud: (h: HudState) => void;
  onGameOver: (r: RunResult) => void;
  onState: (s: GameState) => void;
}

export class HillGame {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  cb: EngineCallbacks;

  w = 0;
  h = 0;
  dpr = 1;
  baseZoom = 1;
  zoom = 1;
  raf = 0;
  last = 0;
  acc = 0;
  time = 0;
  running = false;

  state: GameState = "menu";
  input: InputState = { gas: false, brake: false, boost: false, jump: false };
  jumpCd = 0;
  jumpPulse = 0;

  seed = 1;
  terrain: Terrain = new Terrain(1);

  // body
  x = 300;
  y = 0;
  vx = 0;
  vy = 0;
  angle = 0;
  av = 0;
  wheels: Wheel[] = [];
  grounded = false;
  airTime = 0;
  totalAir = 0;
  flipAccum = 0;
  flips = 0;
  hintTimer = 4.5;

  // run values
  startX = 300;
  score = 0;
  coins = 0;
  fuel = FUEL_MAX;
  boost = 45;
  distance = 0;
  combo = 1;
  comboTimer = 0;
  boosting = false;
  best = 0;

  // death
  dead = false;
  deadTimer = 0;
  cause = "";
  causeIcon = "💥";
  driver: { x: number; y: number; vx: number; vy: number; rot: number; vr: number } | null = null;

  pickups: Pickup[] = [];
  spawnedChunk = 0;
  particles: Particle[] = [];
  texts: FloatText[] = [];
  dust: { x: number; y: number; s: number; p: number }[] = [];

  camX = 0;
  camY = 0;
  shake = 0;
  shakeX = 0;
  shakeY = 0;
  flash = 0;
  skidCd = 0;
  exhaustCd = 0;
  hudAcc = 0;
  audioCd = 0;
  lowFuelBeep = 0;

  skyGrad: CanvasGradient | null = null;
  vignette: CanvasGradient | null = null;
  xs: Float32Array = new Float32Array(700);
  ys: Float32Array = new Float32Array(700);

  constructor(canvas: HTMLCanvasElement, cb: EngineCallbacks) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("2d context unavailable");
    this.ctx = ctx;
    this.cb = cb;
    for (const a of ANCHORS) {
      this.wheels.push({
        lx: a.x,
        ly: a.y,
        wx: 0,
        wy: 0,
        cx: 0,
        cy: 0,
        contact: false,
        pen: 0,
        prevPen: 0,
        spin: 0,
        slip: 0,
      });
    }
    this.resetRun(false);
    this.resize();
  }

  /* ------------------------------------------------------------------ */
  /* lifecycle                                                          */
  /* ------------------------------------------------------------------ */

  mount() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    this.loop(this.last);
  }

  unmount() {
    this.running = false;
    cancelAnimationFrame(this.raf);
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const cw = Math.max(320, rect.width || window.innerWidth);
    const ch = Math.max(320, rect.height || window.innerHeight);
    const area = cw * ch;
    const maxDpr = area > 1_100_000 ? 1.35 : 2;
    this.dpr = Math.min(window.devicePixelRatio || 1, maxDpr);
    this.w = cw;
    this.h = ch;
    this.canvas.width = Math.floor(cw * this.dpr);
    this.canvas.height = Math.floor(ch * this.dpr);
    this.baseZoom = clamp(Math.min(cw / 1180, ch / 660), 0.52, 1.2);
    this.skyGrad = null;
    this.vignette = null;
    this.buildDust();
  }

  /* ------------------------------------------------------------------ */
  /* run control                                                        */
  /* ------------------------------------------------------------------ */

  resetRun(playing: boolean) {
    this.seed = Math.floor(Math.random() * 100000) + 1;
    this.terrain = new Terrain(this.seed);
    this.startX = 320;
    this.x = this.startX;
    this.y = this.terrain.height(this.x) - (REST_LEN + WHEEL_R) - 6;
    this.vx = 0;
    this.vy = 0;
    this.angle = 0;
    this.av = 0;
    this.score = 0;
    this.coins = 0;
    this.fuel = FUEL_MAX;
    this.boost = 45;
    this.distance = 0;
    this.combo = 1;
    this.comboTimer = 0;
    this.grounded = true;
    this.airTime = 0;
    this.totalAir = 0;
    this.flipAccum = 0;
    this.flips = 0;
    this.dead = false;
    this.deadTimer = 0;
    this.driver = null;
    this.cause = "";
    this.lastX = this.x;
    this.stuckTimer = 0;
    this.groundTimer = 0;
    this.nextMilestone = 5000;
    this.pickups = [];
    this.spawnedChunk = 0;
    this.particles = [];
    this.texts = [];
    this.camX = this.x;
    this.camY = this.y - 40;
    this.shake = 0;
    this.flash = 0;
    this.boosting = false;
    this.hintTimer = playing ? 4.5 : 0;
    for (const w of this.wheels) {
      w.pen = 0;
      w.prevPen = 0;
      w.spin = 0;
      w.slip = 0;
      w.contact = false;
    }
    this.buildDust();
    this.spawnAhead();
    this.input.gas = false;
    this.input.brake = false;
    this.input.boost = false;
    this.input.jump = false;
    this.jumpCd = 0;
    this.jumpPulse = 0;
    sfx.silentEngine();
  }

  play() {
    this.resetRun(true);
    this.setState("playing");
  }

  setState(s: GameState) {
    if (this.state === s) return;
    this.state = s;
    this.cb.onState(s);
    if (s !== "playing") sfx.silentEngine();
  }

  pause() {
    if (this.state !== "playing" || this.dead) return;
    this.setState("paused");
    this.pushHud(true);
  }

  resume() {
    if (this.state !== "paused") return;
    this.setState("playing");
    this.last = performance.now();
  }

  togglePause() {
    if (this.state === "playing") this.pause();
    else if (this.state === "paused") this.resume();
  }

  pushHud(force = false) {
    if (!force && this.hudAcc < 0.07) return;
    this.hudAcc = 0;
    this.cb.onHud({
      score: Math.floor(this.score),
      coins: this.coins,
      fuel: this.fuel,
      boost: this.boost,
      speed: Math.hypot(this.vx, this.vy),
      distance: this.distance,
      combo: this.combo,
      flips: this.flips,
      airTime: this.totalAir,
      boosting: this.boosting,
      state: this.state,
    });
  }

  /* ------------------------------------------------------------------ */
  /* loop                                                               */
  /* ------------------------------------------------------------------ */

  loop = (ts: number) => {
    if (!this.running) return;
    this.raf = requestAnimationFrame(this.loop);
    let dt = (ts - this.last) / 1000;
    this.last = ts;
    if (dt > 0.25) dt = 0.25;
    this.hudAcc += dt;

    if (this.state === "paused") return;

    this.acc += dt;
    let steps = 0;
    while (this.acc >= FIXED && steps < 8) {
      this.update(FIXED);
      this.acc -= FIXED;
      steps++;
    }
    if (steps >= 8) this.acc = 0;

    // shake decay uses real time
    this.shake *= Math.exp(-dt * 7);
    if (this.shake < 0.05) this.shake = 0;
    const s = this.shake;
    this.shakeX = (Math.random() * 2 - 1) * s;
    this.shakeY = (Math.random() * 2 - 1) * s * 0.8;
    this.flash *= Math.exp(-dt * 6);

    this.render();
    if (this.hudAcc >= 0.07) this.pushHud();
  };

  /* ------------------------------------------------------------------ */
  /* update                                                             */
  /* ------------------------------------------------------------------ */

  update(h: number) {
    this.time += h;
    if (!Number.isFinite(this.x + this.y + this.angle + this.vx + this.vy + this.av)) {
      // paranoia guard: never let a bad frame break the run
      this.resetRun(this.state === "playing");
      return;
    }
    const menu = this.state === "menu";

    if (menu) {
      // attract mode: the buggy rolls forward, blipping the throttle now and then
      const t = this.time % 5.2;
      this.input.gas = this.x < this.startX + 2100 && t > 2.2 && t < 3.1;
      this.input.brake = false;
      this.input.boost = false;
      if (this.time % 0.75 < h) {
        const c = Math.cos(this.angle);
        const s = Math.sin(this.angle);
        this.smoke(this.x + (c * -42 - s * 6), this.y + (s * -42 + c * 6));
      }
    }

    if (this.hintTimer > 0) this.hintTimer -= h;
    if (this.skidCd > 0) this.skidCd -= h;
    if (this.exhaustCd > 0) this.exhaustCd -= h;

    if (!this.dead) {
      this.updateFuel(h, !menu && this.state === "playing");
      this.stepBody(h, menu);
    } else {
      this.stepBody(h, false);
      if (this.deadTimer > 0) {
        this.deadTimer -= h;
        if (this.deadTimer <= 0 && this.state === "playing") this.finishRun();
      }
    }

    if (this.driver) {
      const d = this.driver;
      d.vy += G * 0.55 * h;
      d.vx *= Math.exp(-0.15 * h);
      d.x += d.vx * h;
      d.y += d.vy * h;
      d.rot += d.vr * h;
      const gy = this.terrain.height(d.x);
      if (d.y > gy - 8) {
        d.y = gy - 8;
        if (Math.abs(d.vy) > 60) {
          d.vy *= -0.35;
          d.vx *= 0.7;
          d.vr *= 0.5;
          this.burst(d.x, d.y, 6, "dust");
        } else {
          d.vy = 0;
          d.vx *= 0.85;
          d.vr *= 0.8;
        }
      }
    }

    if (this.state === "playing") {
      this.spawnAhead();
      this.collectPickups();
      this.camera(h);
      if (!this.dead && this.input.gas) this.exhaust(h);
    } else {
      this.camera(h);
    }

    this.stepParticles(h);
    this.stepTexts(h);
    if (this.comboTimer > 0) {
      this.comboTimer -= h;
      if (this.comboTimer <= 0) this.combo = 1;
    }
    if (this.lowFuelBeep > 0) this.lowFuelBeep -= h;

    // audio (throttled: the synth smooths its own params)
    if (this.state === "playing" && !this.dead) {
      this.audioCd -= h;
      if (this.audioCd <= 0) {
        this.audioCd = 0.05;
        const sp = Math.hypot(this.vx, this.vy);
        const throttle = this.input.gas ? 1 : this.input.brake ? 0.45 : 0;
        sfx.engine(clamp(sp / SPEED_REF, 0, 1.2), this.fuel > 0 ? throttle : 0, this.grounded);
      }
    }
    this.flash = Math.max(0, this.flash);
  }

  private updateFuel(h: number, drain: boolean) {
    if (!drain) return;
    if (this.fuel <= 0) return;
    const load = 1 + (this.input.gas ? 0.55 : 0) + (this.boosting ? 0.5 : 0);
    this.fuel = Math.max(0, this.fuel - FUEL_RATE * load * h);
    if (this.fuel < 22 && this.lowFuelBeep <= 0) {
      this.lowFuelBeep = 0.9;
      this.addText(this.x, this.y - 70, "LOW FUEL!", "#ff6b6b", 20, -34);
    }
  }

  /* ------------------------------------------------------------------ */
  /* physics                                                            */
  /* ------------------------------------------------------------------ */

  private stepBody(h: number, attract: boolean) {
    const cos = Math.cos(this.angle);
    const sin = Math.sin(this.angle);
    const gas = this.input.gas && this.fuel > 0 && !this.dead;
    const brake = this.input.brake && this.fuel > 0 && !this.dead;
    const wantBoost = this.input.boost && this.boost > 1 && !this.dead && this.state === "playing";
    if (wantBoost) {
      this.boosting = true;
      this.boost = Math.max(0, this.boost - 32 * h);
    } else {
      this.boosting = false;
    }
    if (this.boosting && Math.random() < 0.55) {
      this.addParticle(
        this.x + cos * -44 - sin * 2,
        this.y + sin * -44 + cos * 2,
        -this.vx * 0.35 - 60 + Math.random() * 60,
        -this.vy * 0.35 - 30 - Math.random() * 60,
        0.35,
        9 + Math.random() * 10,
        Math.random() < 0.5 ? "#ffd166" : "#ff7b3d",
        "soft"
      );
    }

    // on-demand hop: the signature move for clearing rock and grabbing air
    if (this.jumpCd > 0) this.jumpCd -= h;
    if (this.jumpPulse > 0) this.jumpPulse = Math.max(0, this.jumpPulse - h * 5.5);
    if (
      this.input.jump &&
      this.jumpCd <= 0 &&
      this.grounded &&
      this.groundTimer > 0.06 &&
      !this.dead &&
      this.state === "playing" &&
      this.fuel > 0
    ) {
      this.jumpCd = 0.72;
      this.jumpPulse = 1;
      const boostLift = this.boosting ? 1.24 : 1;
      this.vy = Math.min(this.vy, 0) * 0.3 - 505 * boostLift;
      this.av += this.vx > 0 ? -1.1 : 1.1;
      this.burst(this.x, this.y + 28, 10, "dust");
      this.shake += 6;
      this.flash = Math.max(this.flash, 0.08);
      sfx.boost();
    }

    // gravity + drag
    this.vy += G * h;
    const sp = Math.hypot(this.vx, this.vy);
    if (sp > 1) {
      const d = COST_DRAG * sp * h;
      this.vx -= this.vx * d;
      this.vy -= this.vy * d;
    }

    // air control / reaction torque
    if (this.grounded) {
      if (gas) this.av -= GROUND_TORQUE * h;
      if (brake) this.av += GROUND_TORQUE * 0.8 * h;
    } else {
      if (gas) this.av -= AIR_ACC * h;
      if (brake) this.av += AIR_ACC * h;
    }
    const avCap = this.grounded ? 9 : AIR_AV_CAP;
    this.av = clamp(this.av, -avCap, avCap);
    const angDamp = this.grounded ? 3.1 : 0.25;
    this.av *= Math.exp(-angDamp * h);

    this.angle += this.av * h;
    this.x += this.vx * h;
    this.y += this.vy * h;

    // invisible start-line wall keeps the run moving forward
    if (this.x < -50) {
      this.x = -50;
      if (this.vx < 0) this.vx *= -0.25;
    }

    const c2 = Math.cos(this.angle);
    const s2 = Math.sin(this.angle);
    let anyContact = false;
    let maxImpact = 0;
    const nrm = { x: 0, y: 0 };
    const tan = { x: 1, y: 0 };

    for (const w of this.wheels) {
      const ax = this.x + (w.lx * c2 - w.ly * s2);
      const ay = this.y + (w.lx * s2 + w.ly * c2);
      w.cx = ax - s2 * REST_LEN;
      w.cy = ay + c2 * REST_LEN;
      const gy = this.terrain.height(w.cx);
      const pen = w.cy + WHEEL_R - gy;
      w.pen = pen;
      w.contact = pen > 0.4;
      if (pen <= 0) {
        w.prevPen = pen;
        continue;
      }
      anyContact = true;
      this.terrain.normal(w.cx, nrm);
      this.terrain.tangent(w.cx, tan);

      const rx = w.cx - this.x;
      const ry = w.cy - this.y;
      let rvx = this.vx - this.av * ry;
      let rvy = this.vy + this.av * rx;
      const vn = rvx * nrm.x + rvy * nrm.y;
      let N = SPRING_K * Math.min(pen, 26) - SPRING_C * vn;
      N = clamp(N, 0, 4200);

      // hard-landing impact / overlap resolution
      if (w.prevPen <= 0.4 && vn < -60) maxImpact = Math.max(maxImpact, -vn);
      if (pen > 11) {
        const push = (pen - 11) * 0.5;
        this.x += nrm.x * push;
        this.y += nrm.y * push;
        if (vn < 0) {
          const j = vn * 1.06;
          this.vx -= nrm.x * j;
          this.vy -= nrm.y * j;
          rvx = this.vx - this.av * ry;
          rvy = this.vy + this.av * rx;
        }
      }

      let fx = nrm.x * N;
      let fy = nrm.y * N;
      const vt = rvx * tan.x + rvy * tan.y;

      // drive / brake
      const dir = (gas ? 1 : 0) - (brake ? 1 : 0);
      if (dir !== 0) {
        const maxSp = dir > 0 ? (this.boosting ? MAX_SPEED * 1.3 : MAX_SPEED) : MAX_REVERSE;
        const curve = clamp(1 - (vt * dir) / maxSp, 0, 1);
        let Ft = dir * DRIVE * curve * (this.boosting ? 0.95 : 0.5);
        const grip = MU * N * 0.5;
        if (Math.abs(Ft) > grip) {
          w.slip = 1;
          Ft = Math.sign(Ft) * grip;
          if (Math.random() < 0.5) this.skidFx(w.cx, w.cy, vt, nrm, tan);
        } else {
          w.slip = Math.max(0, w.slip - h * 4);
        }
        fx += tan.x * Ft;
        fy += tan.y * Ft;
      } else {
        w.slip = Math.max(0, w.slip - h * 4);
      }

      // rolling resistance
      const roll = -vt * 0.18 * clamp(N / 800, 0, 1.6);
      fx += tan.x * roll;
      fy += tan.y * roll;

      // integrate forces on the body
      this.vx += (fx * h) / 1;
      this.vy += (fy * h) / 1;
      this.av += ((rx * fy - ry * fx) / INERTIA) * h;

      w.spin += (vt / WHEEL_R) * h + w.slip * dir * h * 14;
      w.prevPen = pen;

      if (w.slip > 0.6 && Math.random() < 0.4) {
        this.addParticle(
          w.cx + nrm.x * WHEEL_R,
          w.cy + nrm.y * WHEEL_R,
          -this.vx * 0.25 + (Math.random() - 0.5) * 90,
          -Math.abs(this.vx) * 0.12 - 40 - Math.random() * 60,
          0.4 + Math.random() * 0.3,
          3 + Math.random() * 4,
          "rgba(120,84,58,1)",
          "soft"
        );
      }
      if (Math.abs(vt) > 260 && Math.random() < 0.12) {
        this.addParticle(
          w.cx,
          w.cy + WHEEL_R * 0.8,
          -this.vx * 0.18 + (Math.random() - 0.5) * 60,
          -30 - Math.random() * 40,
          0.5,
          6 + Math.random() * 6,
          "rgba(206,190,170,1)",
          "soft"
        );
      }
    }

    // chassis colliders (keeps the buggy from sinking when flipped)
    for (const p of BODY_PTS) {
      const px = this.x + (p.x * c2 - p.y * s2);
      const py = this.y + (p.x * s2 + p.y * c2);
      const gy = this.terrain.height(px);
      const pen = py + p.r - gy;
      if (pen <= 0) continue;
      anyContact = true;
      this.terrain.normal(px, nrm);
      const rx = px - this.x;
      const ry = py - this.y;
      const vn = this.vx * nrm.x + this.vy * nrm.y + this.av * (rx * nrm.y - ry * nrm.x);
      const N = clamp(BODY_K * Math.min(pen, 18) - BODY_C * vn, 0, 6000);
      const fx = nrm.x * N;
      const fy = nrm.y * N;
      this.vx += fx * h;
      this.vy += fy * h;
      this.av += ((rx * fy - ry * fx) / INERTIA) * h * 0.6;
    }

    // ground / air state & trick bookkeeping
    const wasGrounded = this.grounded;
    this.grounded = anyContact;
    if (!wasGrounded && anyContact) {
      // landing
      if (this.airTime > 0.32 && this.state === "playing") {
        const bonus = Math.round(this.airTime * 55) * this.combo;
        this.score += bonus;
        this.addText(this.x, this.y - 60, `AIR +${bonus}`, "#8ef2ff", 19, -46);
        this.bumpCombo();
      }
      const power = clamp(maxImpact / 1500, 0, 1);
      if (maxImpact > 120) {
        sfx.land(maxImpact / 1600);
        this.shake += Math.min(16, maxImpact / 90);
        this.burst(this.x, this.y + 26, 5 + Math.floor(power * 12), "dust");
        if (maxImpact > 1500) {
          this.flash = Math.max(this.flash, 0.22);
          this.addText(this.x, this.y - 50, "WHOMP!", "#ffd166", 22, -60);
        }
      }
      this.airTime = 0;
      this.groundTimer = 0;
    }
    if (anyContact) {
      // a brief wheel graze must not wipe out an in-progress flip
      this.groundTimer += h;
      if (this.groundTimer > 0.14) this.flipAccum = 0;
    }
    if (!anyContact) {
      this.groundTimer = 0;
      this.airTime += h;
      this.totalAir += h;
      this.flipAccum += this.av * h;
      const need = Math.PI * 1.6;
      if (Math.abs(this.flipAccum) > need && this.airTime > 0.22) {
        const backflip = this.flipAccum < 0;
        this.flips++;
        this.combo = Math.min(9, this.combo + 1);
        this.comboTimer = 2.6;
        const bonus = 170 * this.combo;
        this.score += bonus;
        this.boost = Math.min(100, this.boost + 16);
        this.addText(
          this.x,
          this.y - 66,
          `${backflip ? "BACKFLIP" : "FRONTFLIP"} +${bonus}`,
          backflip ? "#ffd166" : "#ff9ecd",
          24,
          -52
        );
        sfx.flip();
        this.burst(this.x, this.y, 16, "spark");
        this.shake += 9;
        this.flipAccum -= Math.sign(this.flipAccum) * need;
      }
    } else {
      this.flipAccum = 0;
    }

    // head vs ground -> crash
    if (this.state === "playing" && !this.dead && !attract) {
      const hx = this.x + (HEAD.x * c2 - HEAD.y * s2);
      const hy = this.y + (HEAD.x * s2 + HEAD.y * c2);
      if (hy > this.terrain.height(hx) - 7) this.kill("HEAD CRASH", "🤕");
    }

    // slow creep / stuck detection when out of fuel
    if (this.state === "playing" && !this.dead && this.fuel <= 0) {
      const sp2 = Math.hypot(this.vx, this.vy);
      if (sp2 < 95 && this.grounded) {
        this.stuckTimer = (this.stuckTimer ?? 0) + h;
        if (this.stuckTimer > 2.2) {
          this.stuckTimer = 0;
          this.kill("OUT OF FUEL", "⛽");
        }
      } else {
        this.stuckTimer = 0;
      }
    }

    // safety clamps: keep the simulation in a sane range no matter what
    this.vx = clamp(this.vx, -2600, 2600);
    this.vy = clamp(this.vy, -2600, 2600);
    this.av = clamp(this.av, -14, 14);

    // distance milestones: a little celebration every 250 m
    if (this.x > this.nextMilestone) {
      const metres = Math.round(this.nextMilestone / 20);
      this.nextMilestone += 5000;
      if (this.state === "playing" && !this.dead) {
        const gain = 250 * this.combo;
        this.score += gain;
        this.bumpCombo();
        this.addText(this.x, this.y - 84, `${metres}m MILESTONE  +${gain}`, "#a7ff8e", 22, -58);
        this.burst(this.x, this.y - 10, 16, "spark");
        this.flash = Math.max(this.flash, 0.12);
        this.shake += 5;
        sfx.levelUp();
      }
    }

    // score from distance
    const adv = this.x - this.startX;
    if (adv > this.distance) this.distance = adv;
    if (this.state === "playing") this.score += Math.max(0, (this.x - this.lastX) / 20) * 4.5;
    this.lastX = this.x;
  }

  private lastX = 0;
  private stuckTimer = 0;
  private groundTimer = 0;
  private nextMilestone = 5000;

  /* ------------------------------------------------------------------ */
  /* feedback                                                           */
  /* ------------------------------------------------------------------ */

  bumpCombo() {
    this.combo = Math.min(9, this.combo + 1);
    this.comboTimer = 2.6;
  }

  addParticle(
    x: number,
    y: number,
    vx: number,
    vy: number,
    life: number,
    size: number,
    c: string,
    kind: Particle["kind"] = "soft",
    grav = 900,
    drag = 1.1
  ) {
    if (this.particles.length > 330) this.particles.shift();
    this.particles.push({
      x,
      y,
      vx,
      vy,
      life,
      max: life,
      size,
      rot: Math.random() * 6.28,
      vr: (Math.random() - 0.5) * 12,
      c,
      kind,
      grav,
      drag,
    });
  }

  burst(x: number, y: number, count: number, type: "dust" | "spark" | "debris" | "coin") {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 40 + Math.random() * 220;
      if (type === "dust") {
        this.addParticle(
          x + (Math.random() - 0.5) * 24,
          y + (Math.random() - 0.5) * 12,
          Math.cos(a) * sp * 0.7,
          -Math.abs(Math.sin(a) * sp) * 0.5 - 20,
          0.5 + Math.random() * 0.5,
          5 + Math.random() * 9,
          "rgba(206,186,162,1)",
          "soft",
          240,
          1.4
        );
      } else if (type === "spark") {
        this.addParticle(
          x + (Math.random() - 0.5) * 30,
          y + (Math.random() - 0.5) * 30,
          Math.cos(a) * sp,
          Math.sin(a) * sp,
          0.25 + Math.random() * 0.3,
          2 + Math.random() * 3,
          Math.random() < 0.5 ? "#ffe066" : "#fff3c4",
          "square",
          300,
          0.6
        );
      } else if (type === "debris") {
        this.addParticle(
          x,
          y,
          Math.cos(a) * sp * 1.4,
          Math.sin(a) * sp * 1.4 - 120,
          0.9 + Math.random() * 0.7,
          4 + Math.random() * 6,
          Math.random() < 0.5 ? "#e8412f" : "#2c2530",
          "square",
          1500,
          0.5
        );
      } else {
        this.addParticle(
          x,
          y,
          Math.cos(a) * sp * 0.8,
          Math.sin(a) * sp * 0.8 - 60,
          0.4 + Math.random() * 0.4,
          2 + Math.random() * 4,
          "#ffe066",
          "ring",
          500,
          0.8
        );
      }
    }
  }

  addText(x: number, y: number, text: string, color: string, size: number, vy = -46) {
    this.texts.push({ x, y, vy, life: 1.1, max: 1.1, text, color, size });
    if (this.texts.length > 14) this.texts.shift();
  }

  skidFx(cx: number, cy: number, vt: number, nrm: { x: number; y: number }, tan: { x: number; y: number }) {
    if (this.skidCd > 0) return;
    this.skidCd = 0.09;
    sfx.skid();
    const dir = Math.sign(vt) || 1;
    for (let i = 0; i < 3; i++) {
      this.addParticle(
        cx + nrm.x * WHEEL_R,
        cy + nrm.y * WHEEL_R,
        tan.x * -dir * (60 + Math.random() * 120) + (Math.random() - 0.5) * 40,
        -60 - Math.random() * 70,
        0.35 + Math.random() * 0.3,
        3 + Math.random() * 5,
        "rgba(118,80,54,1)",
        "soft",
        700,
        1.2
      );
    }
  }

  smoke(x: number, y: number) {
    this.addParticle(
      x,
      y,
      -this.vx * 0.15 + (Math.random() - 0.5) * 30,
      -40 - Math.random() * 40,
      0.7 + Math.random() * 0.4,
      6 + Math.random() * 10,
      "rgba(196,186,178,1)",
      "soft",
      -120,
      1.6
    );
  }

  private exhaust(h: number) {
    if (this.exhaustCd > 0) return;
    this.exhaustCd = 0.1;
    const c = Math.cos(this.angle);
    const s = Math.sin(this.angle);
    this.smoke(this.x + (c * -42 - s * 6), this.y + (s * -42 + c * 6));
    void h;
  }

  kill(cause: string, icon: string) {
    if (this.dead) return;
    this.dead = true;
    this.deadTimer = 1.25;
    this.cause = cause;
    this.causeIcon = icon;
    this.input.gas = false;
    sfx.crash();
    this.shake = 26;
    this.flash = 0.5;
    this.burst(this.x, this.y - 10, 26, "debris");
    this.burst(this.x, this.y + 20, 22, "dust");
    const c = Math.cos(this.angle);
    const s = Math.sin(this.angle);
    this.driver = {
      x: this.x + (HEAD.x * c - HEAD.y * s),
      y: this.y + (HEAD.x * s + HEAD.y * c),
      vx: this.vx * 0.7 - 60 - Math.random() * 80,
      vy: -330 - Math.random() * 180,
      rot: this.angle,
      vr: -6 - Math.random() * 4,
    };
    this.av += 3;
    this.camera(1 / 60, true);
  }

  finishRun() {
    const res: RunResult = {
      score: Math.floor(this.score),
      distance: Math.floor(this.distance / 20),
      coins: this.coins,
      flips: this.flips,
      airTime: Math.round(this.totalAir),
      cause: this.cause,
      causeIcon: this.causeIcon,
    };
    this.setState("gameover");
    sfx.gameOver();
    this.cb.onGameOver(res);
  }

  /* ------------------------------------------------------------------ */
  /* pickups                                                            */
  /* ------------------------------------------------------------------ */

  private spawnAhead() {
    const limit = this.camX + this.w / this.zoom + CHUNK * 2;
    while (this.spawnedChunk * CHUNK < limit) {
      const chunk = chunkPickups(this.spawnedChunk, this.terrain, this.seed);
      for (const p of chunk) this.pickups.push(p);
      this.spawnedChunk++;
    }
    if (this.pickups.length > 260) {
      const cut = this.camX - 900;
      let n = 0;
      while (n < this.pickups.length && this.pickups[n].x < cut) n++;
      if (n > 0) this.pickups.splice(0, n);
    }
  }

  private collectPickups() {
    const cr = 46;
    for (const p of this.pickups) {
      if (p.taken) continue;
      const dx = p.x - this.x;
      const dy = p.y - this.y;
      if (dx * dx + dy * dy > cr * cr) continue;
      p.taken = true;
      if (p.kind === "coin") {
        const gain = 25 * this.combo;
        this.score += gain;
        this.coins++;
        this.boost = Math.min(100, this.boost + 8);
        this.bumpCombo();
        sfx.coin(this.coins % 5);
        this.addText(p.x, p.y - 12, `+${gain}`, "#ffe066", 18, -58);
        this.burst(p.x, p.y, 7, "coin");
        this.shake += 1.6;
      } else {
        this.fuel = Math.min(FUEL_MAX, this.fuel + 34);
        sfx.pickupFuel();
        this.addText(p.x, p.y - 14, "+FUEL", "#7dffa8", 21, -52);
        this.burst(p.x, p.y, 10, "spark");
        this.flash = Math.max(this.flash, 0.1);
        this.shake += 2.5;
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* camera                                                             */
  /* ------------------------------------------------------------------ */

  private camera(h: number, snap = false) {
    const lead = clamp(this.vx * 0.42, -240, 420);
    const targetX = this.x + lead;
    const targetY = this.y + clamp(this.vy * 0.16, -110, 260) - 30;
    const kx = snap ? 1 : 1 - Math.exp(-4.6 * h);
    const ky = snap ? 1 : 1 - Math.exp(-3.4 * h);
    this.camX += (targetX - this.camX) * kx;
    this.camY += (targetY - this.camY) * ky;
    const speed = Math.hypot(this.vx, this.vy);
    const targetZoom = this.baseZoom * clamp(1.06 - speed / 5200, 0.82, 1.06) * (this.boosting ? 0.96 : 1);
    this.zoom += (targetZoom - this.zoom) * (snap ? 1 : 1 - Math.exp(-3 * h));
  }

  /* ------------------------------------------------------------------ */
  /* particles & text                                                   */
  /* ------------------------------------------------------------------ */

  private stepParticles(h: number) {
    const arr = this.particles;
    // terrain sampling is the expensive part, so alternate it between substeps
    this.particleTick = (this.particleTick + 1) % 2;
    const sampleGround = this.particleTick === 0;
    for (let i = arr.length - 1; i >= 0; i--) {
      const p = arr[i];
      p.life -= h;
      if (p.life <= 0) {
        arr[i] = arr[arr.length - 1];
        arr.pop();
        continue;
      }
      p.vy += p.grav * h;
      const d = Math.exp(-p.drag * h);
      p.vx *= d;
      p.vy *= d;
      p.x += p.vx * h;
      p.y += p.vy * h;
      p.rot += p.vr * h;
      if (sampleGround && p.kind !== "ring") {
        const gy = this.terrain.height(p.x);
        if (p.y > gy - 2) {
          p.y = gy - 2;
          p.vy *= -0.24;
          p.vx *= 0.86;
        }
      }
    }
  }

  private particleTick = 0;

  private stepTexts(h: number) {
    const arr = this.texts;
    for (let i = arr.length - 1; i >= 0; i--) {
      const t = arr[i];
      t.life -= h;
      if (t.life <= 0) {
        arr[i] = arr[arr.length - 1];
        arr.pop();
        continue;
      }
      t.y += t.vy * h;
      t.vy *= Math.exp(-2.4 * h);
    }
  }

  private buildDust() {
    this.dust = [];
    for (let i = 0; i < 40; i++) {
      this.dust.push({
        x: Math.random() * this.w,
        y: Math.random() * this.h * 0.9,
        s: 1 + Math.random() * 2.4,
        p: 0.12 + Math.random() * 0.5,
      });
    }
  }

  /* ------------------------------------------------------------------ */
  /* render                                                             */
  /* ------------------------------------------------------------------ */

  render() {
    const { ctx, w, h } = this;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const night = smoothstep(4000, 26000, this.x);
    const pal: Palette = {
      skyTop: mix(DUSK.skyTop, NIGHT.skyTop, night),
      skyMid: mix(DUSK.skyMid, NIGHT.skyMid, night),
      skyBot: mix(DUSK.skyBot, NIGHT.skyBot, night),
      sun: mix(DUSK.sun, NIGHT.sun, night),
      far: mix(DUSK.far, NIGHT.far, night),
      mid: mix(DUSK.mid, NIGHT.mid, night),
      near: mix(DUSK.near, NIGHT.near, night),
      grass: mix(DUSK.grass, NIGHT.grass, night),
      grassHi: mix(DUSK.grassHi, NIGHT.grassHi, night),
      soil: mix(DUSK.soil, NIGHT.soil, night),
      soilDeep: mix(DUSK.soilDeep, NIGHT.soilDeep, night),
      rock: mix(DUSK.rock, NIGHT.rock, night),
    };

    const camX = this.camX + this.shakeX;
    const camY = this.camY + this.shakeY;

    this.drawSky(pal, night, camX);
    this.drawParallax(pal, camX, night);
    this.drawDust(camX);

    ctx.save();
    ctx.translate(w / 2, h * 0.62);
    ctx.scale(this.zoom, this.zoom);
    ctx.translate(-camX, -camY);
    this.drawTerrain(pal, camX, camY);
    this.drawMarkers(camX, pal);
    this.drawPickups();
    this.drawParticles(false);
    if (!this.dead) this.drawCarShadow();
    if (!this.dead) this.drawCar();
    this.drawParticles(true);
    if (this.driver) this.drawFlyingDriver(pal);
    this.drawTexts();
    ctx.restore();

    this.drawFxOverlay(pal);
  }

  private drawSky(pal: Palette, night: number, camX: number) {
    const { ctx, w, h } = this;
    const horizon = h * 0.78;
    const g = ctx.createLinearGradient(0, 0, 0, horizon + 40);
    g.addColorStop(0, rgba(pal.skyTop));
    g.addColorStop(0.52, rgba(pal.skyMid));
    g.addColorStop(1, rgba(pal.skyBot));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, horizon + 42);
    ctx.fillStyle = rgba(pal.skyBot, 0.35);
    ctx.fillRect(0, horizon + 34, w, h - horizon - 34);

    // stars
    if (night > 0.02) {
      ctx.fillStyle = `rgba(255,255,255,${0.85 * night})`;
      for (let i = 0; i < 60; i++) {
        const sx = (hash1(i * 3.7, 9) * 1.2 - 0.08) * w - (camX * 0.04) % w;
        const px = ((sx % w) + w) % w;
        const py = hash1(i * 7.9, 21) * h * 0.5;
        const tw = 0.6 + 0.4 * Math.sin(this.time * 2 + i);
        const s = hash1(i * 1.3, 33) > 0.92 ? 3 : 2;
        ctx.globalAlpha = night * tw;
        ctx.fillRect(px, py, s, s);
      }
      ctx.globalAlpha = 1;
    }

    // sun
    const sunX = w * 0.68;
    const sunY = h * 0.5;
    const sunR = Math.min(w, h) * 0.13;
    const sunAlpha = 1 - night * 0.35;
    ctx.fillStyle = rgba(pal.sun, 0.24 * sunAlpha);
    ctx.beginPath();
    ctx.arc(sunX, sunY, sunR * 1.7, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = rgba(pal.sun, 0.92 * sunAlpha);
    ctx.beginPath();
    ctx.arc(sunX, sunY, sunR, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = rgba(pal.skyMid, 0.55);
    for (let i = 0; i < 3; i++) {
      const yy = sunY + sunR * 0.18 + i * sunR * 0.3;
      ctx.fillRect(sunX - sunR * 1.05, yy, sunR * 2.1, 3 + i * 1.6);
    }
  }

  private drawParallax(pal: Palette, camX: number, night: number) {
    const { ctx, w, h } = this;
    const layers = [
      { p: 0.08, base: 0.72, amp: 120, scale: 900, seed: 3, c: pal.far, lo: 70 },
      { p: 0.18, base: 0.78, amp: 150, scale: 620, seed: 17, c: mix(pal.far, pal.mid, 0.65), lo: 50 },
      { p: 0.34, base: 0.85, amp: 165, scale: 380, seed: 41, c: pal.mid, lo: 34 },
      { p: 0.55, base: 0.93, amp: 150, scale: 230, seed: 73, c: pal.near, lo: 24 },
    ];
    for (const L of layers) {
      const y0 = h * L.base;
      ctx.fillStyle = rgba(L.c, L.p > 0.5 ? 0.96 : 0.82);
      ctx.beginPath();
      ctx.moveTo(-10, h + 10);
      const stepX = 32;
      for (let x = -10; x <= w + 10; x += stepX) {
        const wx = camX * L.p + (x - w / 2) * 0.75;
        const n1 = hash1Less(wx / L.scale, L.seed);
        const n2 = hash1Less(wx / (L.scale * 0.31) + 5, L.seed + 91);
        const y = y0 - (n1 * L.amp + n2 * L.lo);
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w + 10, h + 10);
      ctx.closePath();
      ctx.fill();
      // sun rim light on far layers
      if (L.p < 0.4 && night < 0.6) {
        ctx.strokeStyle = rgba(pal.sun, 0.12 * (1 - night));
        ctx.lineWidth = 1.6;
        ctx.stroke();
      }
    }
  }

  private drawDust(camX: number) {
    const { ctx, w, h } = this;
    ctx.fillStyle = "rgba(255,235,205,0.28)";
    const scroll = camX * 0.06;
    for (const d of this.dust) {
      const x = ((d.x - scroll) % (w + 40) + w + 40) % (w + 40) - 20;
      const y = (d.y + Math.sin(this.time * d.p * 2 + d.x) * 12) % h;
      ctx.fillRect(x, y, d.s, d.s);
    }
  }

  private drawTerrain(pal: Palette, camX: number, camY: number) {
    const { ctx, w, h } = this;
    const halfW = w / 2 / this.zoom + 30;
    const halfH = h / 2 / this.zoom + 40;
    const x0 = camX - halfW;
    const x1 = camX + halfW;
    const bottom = camY + halfH + 220;
    const n = clamp(Math.ceil((x1 - x0) / 8), 60, 420);
    const step = (x1 - x0) / n;
    const xs = this.xs;
    const ys = this.ys;
    for (let i = 0; i <= n; i++) {
      const x = x0 + i * step;
      xs[i] = x;
      ys[i] = this.terrain.height(x);
    }

    // body
    const g = ctx.createLinearGradient(0, camY - halfH, 0, bottom);
    g.addColorStop(0, rgba(pal.soil));
    g.addColorStop(0.35, rgba(pal.soil));
    g.addColorStop(1, rgba(pal.soilDeep));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(xs[0], ys[0]);
    for (let i = 1; i <= n; i++) ctx.lineTo(xs[i], ys[i]);
    ctx.lineTo(xs[n], bottom);
    ctx.lineTo(xs[0], bottom);
    ctx.closePath();
    ctx.fill();

    // grassy crust lying just beneath the crest so wheels read as touching it
    ctx.beginPath();
    ctx.moveTo(xs[0], ys[0] + 1);
    for (let i = 1; i <= n; i++) ctx.lineTo(xs[i], ys[i] + 1);
    for (let i = n; i >= 0; i--) ctx.lineTo(xs[i], ys[i] + 16);
    ctx.closePath();
    ctx.fillStyle = rgba(pal.grass);
    ctx.fill();
    ctx.strokeStyle = rgba(pal.soilDeep, 0.45);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(xs[0], ys[0] + 16);
    for (let i = 1; i <= n; i++) ctx.lineTo(xs[i], ys[i] + 16);
    ctx.stroke();

    // sunlit crest
    ctx.beginPath();
    ctx.moveTo(xs[0], ys[0]);
    for (let i = 1; i <= n; i++) ctx.lineTo(xs[i], ys[i]);
    ctx.strokeStyle = rgba(pal.grassHi, 0.95);
    ctx.lineWidth = 3;
    ctx.stroke();

    // texture: pebbles + rock hatch
    ctx.fillStyle = rgba(pal.soilDeep, 0.4);
    ctx.strokeStyle = rgba(pal.rock, 0.5);
    ctx.lineWidth = 1.4;
    for (let i = 0; i < n; i += 2) {
      const x = xs[i];
      const y = ys[i];
      const r = hash1(Math.floor(x / 17), 5);
      if (r > 0.72) {
        const s = 2 + r * 3;
        ctx.fillRect(x + (r - 0.5) * 14, y + 26 + r * 28, s, s * 0.7);
      }
      if (i % 6 === 0) {
        const slope = (ys[Math.min(n, i + 2)] - ys[Math.max(0, i - 2)]) / (step * 4);
        if (Math.abs(slope) > 0.42) {
          const len = 10 + Math.min(22, Math.abs(slope) * 22);
          ctx.beginPath();
          ctx.moveTo(x, y + 24);
          ctx.lineTo(x + len * 0.35, y + 24 + len);
          ctx.stroke();
        }
      }
    }
  }

  private drawMarkers(camX: number, pal: Palette) {
    const { ctx, w } = this;
    const every = 5000; // 250 m
    const from = Math.floor((camX - w / this.zoom) / every) * every;
    const to = camX + w / this.zoom;
    for (let x = from; x < to; x += every) {
      if (x < 1200) continue;
      const y = this.terrain.height(x);
      const m = Math.round(x / 20);
      ctx.strokeStyle = "rgba(28,20,26,0.9)";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x, y - 44);
      ctx.stroke();
      ctx.fillStyle = "#ff6b3d";
      ctx.beginPath();
      ctx.moveTo(x, y - 44);
      ctx.lineTo(x + 34, y - 36);
      ctx.lineTo(x, y - 26);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.92)";
      ctx.font = "700 15px Outfit, system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(`${m}m`, x, y - 56);
      ctx.textAlign = "left";
      void pal;
    }
  }

  private drawPickups() {
    const { ctx } = this;
    const t = this.time;
    for (const p of this.pickups) {
      if (p.taken) continue;
      const dx = Math.abs(p.x - this.camX);
      if (dx > this.w / this.zoom / 2 + 80) continue;
      if (p.kind === "coin") {
        const bob = Math.sin(t * 3 + p.spin) * 4;
        const y = p.y + bob;
        const spin = Math.abs(Math.cos(t * 2.6 + p.spin));
        ctx.fillStyle = "rgba(255,224,102,0.18)";
        ctx.beginPath();
        ctx.arc(p.x, y, 26, 0, Math.PI * 2);
        ctx.fill();
        ctx.save();
        ctx.translate(p.x, y);
        ctx.scale(0.35 + spin * 0.65, 1);
        ctx.fillStyle = "#ffcf3f";
        ctx.beginPath();
        ctx.arc(0, 0, 13, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#fff1b0";
        ctx.beginPath();
        ctx.arc(0, 0, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#e09a17";
        ctx.font = "700 12px Outfit, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("$", 0, 4.5);
        ctx.textAlign = "left";
        ctx.restore();
      } else {
        const bob = Math.sin(t * 2.4 + p.x * 0.01) * 3;
        const y = p.y + bob;
        ctx.fillStyle = "rgba(125,255,168,0.18)";
        ctx.beginPath();
        ctx.arc(p.x, y, 30, 0, Math.PI * 2);
        ctx.fill();
        ctx.save();
        ctx.translate(p.x, y);
        ctx.fillStyle = "#e2413a";
        ctx.beginPath();
        ctx.roundRect(-15, -20, 30, 40, 6);
        ctx.fill();
        ctx.fillStyle = "#b52a26";
        ctx.fillRect(-15, -20, 30, 8);
        ctx.fillStyle = "#ffe8d6";
        ctx.font = "800 16px Outfit, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("⛽", 0, 6);
        ctx.textAlign = "left";
        ctx.strokeStyle = "#8d1f1c";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-6, -22);
        ctx.lineTo(-6, -28);
        ctx.lineTo(8, -28);
        ctx.stroke();
        ctx.restore();
      }
    }
  }

  private drawParticles(front: boolean) {
    const { ctx } = this;
    for (const p of this.particles) {
      const a = clamp(p.life / p.max, 0, 1);
      if ((p.kind === "ring" || p.kind === "square") !== front) continue;
      ctx.globalAlpha = a;
      if (p.kind === "soft") {
        ctx.fillStyle = p.c;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (0.6 + a * 0.6), 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.c;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * (p.kind === "ring" ? 0.5 : 0.7));
        ctx.restore();
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawTexts() {
    const { ctx } = this;
    ctx.textAlign = "center";
    for (const t of this.texts) {
      const a = clamp(t.life / t.max, 0, 1);
      const pop = 1 + (1 - a) * 0.25;
      ctx.globalAlpha = Math.min(1, a * 1.6);
      ctx.font = `800 ${t.size * pop}px Outfit, system-ui, sans-serif`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(20,10,18,0.85)";
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;
    ctx.textAlign = "left";
  }

  private drawCarShadow() {
    const { ctx } = this;
    const gy = this.terrain.height(this.x + 8);
    const dist = clamp(1 - (gy - this.y) / 200, 0.1, 1);
    ctx.fillStyle = `rgba(24,12,20,${0.3 * dist})`;
    ctx.save();
    ctx.translate(this.x + 10, gy - 2);
    ctx.scale(1, 0.28);
    ctx.beginPath();
    ctx.arc(0, 0, 52 * dist, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  private wheelDraw(
    wx: number,
    wy: number,
    spin: number,
    compress: number,
    ax: number,
    ay: number,
    skid: number
  ) {
    const { ctx } = this;
    // suspension arm
    ctx.strokeStyle = "#2b2231";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(wx, wy);
    ctx.stroke();
    ctx.strokeStyle = "#5b4a63";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(wx, wy);
    ctx.stroke();

    const r = WHEEL_R + 1;
    ctx.fillStyle = "#211a24";
    ctx.beginPath();
    ctx.arc(wx, wy, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#0f0b12";
    ctx.lineWidth = 3;
    ctx.stroke();

    // tread blocks
    ctx.strokeStyle = "#413744";
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const a = spin + (i * Math.PI) / 4;
      const c = Math.cos(a);
      const s = Math.sin(a);
      ctx.moveTo(wx + c * (r - 1), wy + s * (r - 1));
      ctx.lineTo(wx + c * (r - 5), wy + s * (r - 5));
    }
    ctx.stroke();

    // hub
    ctx.fillStyle = "#f0a33c";
    ctx.beginPath();
    ctx.arc(wx, wy, 5.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#8d5a19";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(wx, wy);
    ctx.lineTo(wx + Math.cos(spin) * 5.4, wy + Math.sin(spin) * 5.4);
    ctx.stroke();

    if (skid > 0.6 && Math.random() < 0.3) {
      ctx.fillStyle = "rgba(206,186,162,0.25)";
      ctx.beginPath();
      ctx.arc(wx - compress * 0.5, wy + r, 6 + Math.random() * 6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawCar() {
    const { ctx } = this;
    const c = Math.cos(this.angle);
    const s = Math.sin(this.angle);
    for (const w of this.wheels) {
      const ax = this.x + (w.lx * c - w.ly * s);
      const ay = this.y + (w.lx * s + w.ly * c);
      const comp = clamp(w.pen, 0, 10);
      this.wheelDraw(w.cx, w.cy - comp * 0.85, w.spin, comp, ax, ay, w.slip);
    }

    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.angle);
    const sq = this.jumpPulse;
    if (sq > 0.01) {
      // squash-and-stretch pop when the buggy springs off the ground
      ctx.scale(1 + sq * 0.07, 1 - sq * 0.14);
    }

    // exhaust pipe
    ctx.fillStyle = "#8a8388";
    ctx.fillRect(-46, 2, 10, 7);

    // body
    ctx.beginPath();
    ctx.moveTo(-46, 8);
    ctx.lineTo(-40, -12);
    ctx.lineTo(-6, -16);
    ctx.lineTo(26, -14);
    ctx.lineTo(46, -4);
    ctx.lineTo(48, 8);
    ctx.lineTo(40, 15);
    ctx.lineTo(-38, 15);
    ctx.closePath();
    ctx.fillStyle = "#e8412f";
    ctx.fill();
    ctx.strokeStyle = "#8f1d14";
    ctx.lineWidth = 3;
    ctx.stroke();

    // cream stripe + nose highlight
    ctx.fillStyle = "#ffe6c4";
    ctx.beginPath();
    ctx.moveTo(-38, -12);
    ctx.lineTo(-6, -16);
    ctx.lineTo(24, -14);
    ctx.lineTo(46, -4);
    ctx.lineTo(44, 1);
    ctx.lineTo(-38, -6);
    ctx.closePath();
    ctx.fill();

    // cockpit
    ctx.fillStyle = "#2c2530";
    ctx.beginPath();
    ctx.roundRect(-24, -14, 32, 16, 5);
    ctx.fill();

    // roll cage
    ctx.strokeStyle = "#3a3242";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(-26, -6);
    ctx.lineTo(-16, -30);
    ctx.lineTo(6, -30);
    ctx.lineTo(14, -8);
    ctx.stroke();
    ctx.strokeStyle = "#6f6279";
    ctx.lineWidth = 2;
    ctx.stroke();

    this.drawDriver(ctx);

    ctx.restore();
  }

  private drawDriver(ctx: CanvasRenderingContext2D) {
    const lean = clamp(this.input.gas ? 1 : this.input.brake ? -1 : 0, -1, 1);
    const air = !this.grounded && this.airTime > 0.3;
    const bob = Math.sin(this.time * 13) * (this.grounded ? 1.3 : 0.4);
    const turn = clamp(this.av * 0.06, -0.4, 0.4);

    // legs
    ctx.strokeStyle = "#2b6f66";
    ctx.lineWidth = 7;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-8, -6);
    ctx.lineTo(-2, 4);
    ctx.lineTo(10, 5);
    ctx.stroke();

    // torso
    ctx.save();
    ctx.translate(-10 + lean * -1.5, -12 + bob * 0.4);
    ctx.rotate(lean * 0.16 + turn * 0.5);
    ctx.fillStyle = "#2fa89a";
    ctx.beginPath();
    ctx.roundRect(-8, -14, 16, 18, 6);
    ctx.fill();
    ctx.fillStyle = "#1f7c72";
    ctx.fillRect(-8, 0, 16, 4);

    // arms to wheel
    const armLift = air ? -12 : 0;
    ctx.strokeStyle = "#2fa89a";
    ctx.lineWidth = 5.5;
    ctx.beginPath();
    ctx.moveTo(2, -10);
    ctx.lineTo(14, -14 + armLift * 0.5);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, -8);
    ctx.lineTo(12, -4 + armLift * 0.3);
    ctx.stroke();

    // head + helmet
    ctx.fillStyle = "#f2c19a";
    ctx.beginPath();
    ctx.arc(-2, -20 + bob, 8.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ff8b3d";
    ctx.beginPath();
    ctx.arc(-2, -21 + bob, 9.4, Math.PI * 1.02, Math.PI * 2.05);
    ctx.fill();
    ctx.fillStyle = "#ffe6c4";
    ctx.beginPath();
    ctx.ellipse(4, -20 + bob, 3.4, 4.6, -0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#22313a";
    ctx.beginPath();
    ctx.arc(5, -20 + bob, 1.7, 0, Math.PI * 2);
    ctx.fill();

    // scarf trailing in the wind
    const wind = clamp(Math.hypot(this.vx, this.vy) / 500, 0, 1.4);
    ctx.strokeStyle = "#ffd166";
    ctx.lineWidth = 4.5;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-6, -22 + bob);
    for (let i = 1; i <= 4; i++) {
      const px = -6 - i * (4 + wind * 5);
      const py = -22 + bob + Math.sin(this.time * 16 - i * 0.9) * (2 + wind * 4) - wind * 1.5;
      ctx.lineTo(px, py);
    }
    ctx.stroke();
    ctx.restore();
  }

  private drawFlyingDriver(pal: Palette) {
    const d = this.driver;
    if (!d) return;
    const { ctx } = this;
    ctx.save();
    ctx.translate(d.x, d.y);
    ctx.rotate(d.rot);
    ctx.fillStyle = "#2fa89a";
    ctx.beginPath();
    ctx.roundRect(-8, -8, 16, 18, 6);
    ctx.fill();
    ctx.strokeStyle = "#2fa89a";
    ctx.lineWidth = 5;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(2, -2);
    ctx.lineTo(14, -8);
    ctx.moveTo(-2, 0);
    ctx.lineTo(-14, -6);
    ctx.stroke();
    ctx.fillStyle = "#f2c19a";
    ctx.beginPath();
    ctx.arc(0, -14, 8.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ff8b3d";
    ctx.beginPath();
    ctx.arc(0, -15, 9.4, Math.PI * 1.02, Math.PI * 2.05);
    ctx.fill();
    ctx.restore();
    ctx.globalAlpha = 0.25;
    ctx.fillStyle = rgba(pal.sun, 0.5);
    ctx.beginPath();
    ctx.arc(d.x, d.y, 26, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  private drawFxOverlay(pal: Palette) {
    const { ctx, w, h } = this;
    // vignette (cached)
    if (!this.vignette) {
      const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.78);
      g.addColorStop(0, "rgba(0,0,0,0)");
      g.addColorStop(1, "rgba(18,8,20,0.55)");
      this.vignette = g;
    }
    ctx.fillStyle = this.vignette;
    ctx.fillRect(0, 0, w, h);

    // speed streaks
    const speed = Math.hypot(this.vx, this.vy);
    if (speed > 700) {
      const a = Math.min(0.3, (speed - 700) / 1200);
      ctx.strokeStyle = rgba(pal.sun, a);
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < 14; i++) {
        const yy = (hash1(i * 5.1, 3) * h + this.time * 120) % h;
        const x = hash1(i * 2.3, 7) * w;
        ctx.moveTo(x, yy);
        ctx.lineTo(x - 60 - a * 260, yy);
      }
      ctx.stroke();
    }

    // boost tint
    if (this.boosting) {
      ctx.fillStyle = `rgba(255,140,60,${0.06 + 0.03 * Math.sin(this.time * 30)})`;
      ctx.fillRect(0, 0, w, h);
    }

    // low fuel warning
    if (this.fuel < 22 && this.state === "playing" && !this.dead) {
      const pulse = 0.5 + 0.5 * Math.sin(this.time * 6);
      ctx.fillStyle = `rgba(224,40,40,${0.05 + pulse * 0.07})`;
      ctx.fillRect(0, 0, w, h);
    }

    // impact flash
    if (this.flash > 0.01) {
      ctx.fillStyle = `rgba(255,244,220,${Math.min(0.6, this.flash)})`;
      ctx.fillRect(0, 0, w, h);
    }
  }
}

/* cheap triangular-ish noise for the far mountains (no per-call alloc) */
function hash1Less(x: number, seed: number): number {
  const i = Math.floor(x);
  const f = x - i;
  const a = hash1(i, seed);
  const b = hash1(i + 1, seed);
  const u = f * f * (3 - 2 * f);
  return lerp(a, b, u);
}
