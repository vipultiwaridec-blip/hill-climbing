import type { HudState } from "@/game/engine";

export function fmt(n: number): string {
  return Math.floor(n).toLocaleString("en-US");
}

interface BarProps {
  value: number;
  color: string;
  track: string;
  glow: string;
  label: string;
  icon: string;
  danger?: boolean;
  pulse?: boolean;
}

function Meter({ value, color, label, icon, danger, pulse }: BarProps) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className="flex items-center gap-2">
      <span className="text-base leading-none drop-shadow">{icon}</span>
      <div className="flex flex-col gap-0.5">
        <div
          className={`relative h-[9px] w-[104px] overflow-hidden rounded-full border border-black/40 bg-black/50 sm:h-3 sm:w-[150px] ${
            danger && pulse ? "anim-ring" : ""
          }`}
        >
          <div
            className="h-full rounded-full transition-[width] duration-100 ease-linear"
            style={{
              width: `${v}%`,
              background: color,
              boxShadow: `0 0 10px ${danger && v < 25 ? "#ff4d4d" : "rgba(255,200,120,0.55)"}`,
            }}
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-white/25 to-transparent" />
        </div>
        <span className="hidden text-[9px] font-bold tracking-[0.18em] text-white/55 sm:block">{label}</span>
      </div>
    </div>
  );
}

interface HudProps {
  hud: HudState;
  best: number;
  muted: boolean;
  canPause: boolean;
  isTouch: boolean;
  onPause: () => void;
  onToggleMute: () => void;
}

export function Hud({ hud, best, muted, canPause, isTouch, onPause, onToggleMute }: HudProps) {
  const speedKmh = Math.round(hud.speed * 0.18);
  const danger = hud.fuel < 25;
  return (
    <div className="pointer-events-none absolute inset-0 select-none font-sans">
      {/* top left: score + meters */}
      <div className="absolute left-2 top-2 flex flex-col items-start gap-1.5 sm:left-4 sm:top-3">
        <div className="chip rounded-2xl px-3 py-1.5 sm:px-4 sm:py-2">
          <div className="text-[9px] font-bold uppercase tracking-[0.22em] text-sunset-200/80">Score</div>
          <div className="font-display text-2xl leading-none text-white text-outline sm:text-4xl">{fmt(hud.score)}</div>
          <div className="mt-0.5 flex items-center gap-2 text-[10px] font-semibold text-white/70 sm:text-xs">
            <span>{hud.distance} m</span>
            <span className="text-white/30">•</span>
            <span>{speedKmh} km/h</span>
          </div>
        </div>
        <div className="chip flex items-center gap-3 rounded-2xl px-3 py-1.5 sm:py-2">
          <Meter
            value={hud.fuel}
            label="FUEL"
            icon="⛽"
            color="linear-gradient(90deg,#7dffa8,#2fd47a)"
            track=""
            glow=""
            danger={danger}
            pulse
          />
          <div className="h-6 w-px bg-white/15" />
          <Meter
            value={hud.boost}
            label={hud.boosting ? "BOOSTING!" : "NITRO"}
            icon="🔥"
            color="linear-gradient(90deg,#ffd166,#ff5f2e)"
            track=""
            glow=""
          />
        </div>
        <div className="chip flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold tracking-wider text-amber-200/80 sm:text-xs">
          <span className="opacity-70">BEST</span>
          <span className="text-white">{fmt(best)}</span>
        </div>
      </div>

      {/* top center: combo */}
      <div className="absolute left-1/2 top-2 flex -translate-x-1/2 flex-col items-center gap-1.5 sm:top-3">
        {hud.combo > 1 && (
          <div
            key={hud.combo}
            className="anim-pop rounded-full bg-gradient-to-r from-amber-300 to-orange-500 px-3 py-0.5 font-display text-sm font-extrabold text-dusk-950 shadow-lg"
          >
            COMBO ×{hud.combo}
          </div>
        )}
      </div>

      {/* top right: buttons */}
      <div className="pointer-events-auto absolute right-2 top-2 flex items-center gap-2 sm:right-4 sm:top-3">
        <div className="chip flex items-center gap-1 rounded-full px-2.5 py-1.5 text-sm font-extrabold text-amber-200 sm:text-base">
          <span className="text-xs">🪙</span>
          <span className="text-white">{hud.coins}</span>
        </div>
        <button
          type="button"
          aria-label={muted ? "Unmute" : "Mute"}
          onClick={onToggleMute}
          className="glass-chip chip flex h-9 w-9 items-center justify-center rounded-full text-base text-white/90 sm:h-10 sm:w-10"
        >
          {muted ? "🔇" : "🔊"}
        </button>
        <button
          type="button"
          aria-label="Pause"
          onClick={onPause}
          disabled={!canPause}
          className="glass-chip chip flex h-9 w-9 items-center justify-center rounded-full text-base text-white/90 disabled:opacity-30 sm:h-10 sm:w-10"
        >
          ⏸
        </button>
      </div>

      {/* hint */}
      {hud.state === "playing" && hud.distance < 45 && (
        <div className="anim-in absolute bottom-[30%] left-1/2 max-w-[92vw] -translate-x-1/2 rounded-full bg-black/55 px-4 py-1.5 text-center text-[11px] font-bold tracking-wide text-white/85 sm:text-sm">
          {isTouch ? (
            <>
              HOLD <span className="text-sky-300">RIGHT</span> side to climb •{" "}
              <span className="text-sky-300">JUMP</span> for air • <span className="text-amber-300">NITRO</span> to fly
            </>
          ) : (
            <>
              HOLD <span className="text-sky-300">→</span> to climb • <span className="text-sky-300">SPACE</span> to
              jump • <span className="text-amber-300">SHIFT</span> for nitro
            </>
          )}
        </div>
      )}

      {/* nitro hint when charged */}
      {hud.state === "playing" && hud.boost > 96 && hud.distance > 40 && (
        <div className="absolute bottom-[19%] left-1/2 -translate-x-1/2 rounded-full bg-orange-500/25 px-3 py-1 text-[10px] font-bold text-orange-100">
          NITRO READY — hold SHIFT / BOOST
        </div>
      )}
    </div>
  );
}
