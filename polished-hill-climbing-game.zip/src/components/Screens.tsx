import type { RunResult } from "@/game/engine";
import type { ScoreEntry } from "@/game/storage";
import { fmt } from "./Hud";

function Btn({
  children,
  onClick,
  variant = "ghost",
  size = "md",
  className = "",
}: {
  children: React.ReactNode;
  onClick: () => void;
  variant?: "sun" | "ghost";
  size?: "md" | "lg";
  className?: string;
}) {
  const base =
    variant === "sun"
      ? "btn-sun text-dusk-950 font-display font-extrabold"
      : "btn-ghost text-white/90 font-bold";
  const sz = size === "lg" ? "px-8 py-3.5 text-xl" : "px-5 py-2.5 text-sm";
  return (
    <button type="button" onClick={onClick} className={`rounded-2xl ${base} ${sz} ${className}`}>
      {children}
    </button>
  );
}

function ScoreTable({ scores, highlight }: { scores: ScoreEntry[]; highlight?: number }) {
  if (!scores.length) {
    return (
      <p className="rounded-xl bg-black/25 px-4 py-3 text-center text-xs font-semibold text-white/50">
        No runs yet — the hills are empty. Go plant a flag! 🚩
      </p>
    );
  }
  return (
    <div className="flex flex-col gap-1">
      {scores.slice(0, 5).map((s, i) => {
        const active = highlight !== undefined && s.date === highlight;
        return (
          <div
            key={`${s.date}-${i}`}
            className={`flex items-center gap-3 rounded-xl px-3 py-1.5 text-sm ${
              active
                ? "bg-gradient-to-r from-amber-400/35 to-orange-500/20 ring-1 ring-amber-300/60"
                : "bg-black/25"
            }`}
          >
            <span
              className={`w-5 text-center font-display text-base ${
                i === 0 ? "text-amber-300" : "text-white/40"
              }`}
            >
              {i + 1}
            </span>
            <span className="flex-1 font-display text-lg text-white text-outline">{fmt(s.score)}</span>
            <span className="text-[11px] font-semibold text-white/50">
              {s.distance} m • 🪙 {s.coins}
            </span>
            {active && (
              <span className="rounded-full bg-amber-300 px-2 py-0.5 text-[10px] font-extrabold text-dusk-950">
                NEW
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}

function KeyCap({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="rounded-md border border-white/25 bg-black/40 px-1.5 py-0.5 font-sans text-[10px] font-bold text-white/85">
      {children}
    </kbd>
  );
}

export function StartScreen({
  best,
  scores,
  isTouch,
  onPlay,
}: {
  best: number;
  scores: ScoreEntry[];
  isTouch: boolean;
  onPlay: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-center justify-center overflow-y-auto p-3">
      <div className="panel anim-pop w-full max-w-[420px] rounded-[28px] p-5 sm:p-7">
        <div className="text-center">
          <div className="anim-bob mx-auto mb-1 text-5xl drop-shadow-[0_6px_0_rgba(0,0,0,0.35)]">🚙⛰️</div>
          <h1 className="font-display text-4xl font-extrabold leading-none tracking-tight sm:text-5xl">
            <span className="anim-shine bg-gradient-to-r from-amber-200 via-orange-400 to-amber-200 bg-clip-text text-transparent">
              HILL RUSH
            </span>
          </h1>
          <p className="mt-1 text-xs font-semibold uppercase tracking-[0.24em] text-sunset-200/70">
            climb • jump • backflip
          </p>
        </div>

        <div className="mt-4 flex items-center justify-center gap-2">
          <div className="chip rounded-full px-3 py-1 text-xs font-bold text-white/70">
            🏆 BEST <span className="text-white">{fmt(best)}</span>
          </div>
          <div className="chip rounded-full px-3 py-1 text-xs font-bold text-white/70">
            🪙 coins = score
          </div>
        </div>

        <button
          type="button"
          onClick={onPlay}
          className="btn-sun anim-hue mt-5 w-full rounded-3xl px-6 py-4 font-display text-2xl font-extrabold text-dusk-950 sm:text-3xl"
        >
          ▶ START DRIVING
        </button>

        <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] font-semibold text-white/70">
          {isTouch ? (
            <>
              <div className="chip rounded-xl px-3 py-2">
                <span className="text-sunset-400">RIGHT side</span> = gas
              </div>
              <div className="chip rounded-xl px-3 py-2">
                <span className="text-sunset-400">LEFT side</span> = brake
              </div>
              <div className="chip rounded-xl px-3 py-2">
                <span className="text-sky-300">⤒ JUMP</span> hops up
              </div>
              <div className="chip rounded-xl px-3 py-2">
                <span className="text-amber-300">🔥 NITRO</span> = big air
              </div>
              <div className="chip col-span-2 rounded-xl px-3 py-2">
                In the air: gas = backflip, brake = frontflip. Land on your wheels — head in the dirt ends the run!
              </div>
            </>
          ) : (
            <>
              <div className="chip flex items-center gap-2 rounded-xl px-3 py-2">
                <KeyCap>→</KeyCap>
                <KeyCap>D</KeyCap> gas
              </div>
              <div className="chip flex items-center gap-2 rounded-xl px-3 py-2">
                <KeyCap>←</KeyCap>
                <KeyCap>A</KeyCap> brake
              </div>
              <div className="chip flex items-center gap-2 rounded-xl px-3 py-2">
                <KeyCap>SPACE</KeyCap> jump
              </div>
              <div className="chip flex items-center gap-2 rounded-xl px-3 py-2">
                <KeyCap>SHIFT</KeyCap> nitro
              </div>
              <div className="chip col-span-2 rounded-xl px-3 py-2">
                In the air: gas = backflip, brake = frontflip. Land on your wheels — head in the dirt ends the run!
              </div>
            </>
          )}
        </div>

        <div className="mt-4">
          <h2 className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.22em] text-white/45">
            Hall of climb
          </h2>
          <ScoreTable scores={scores} />
        </div>
      </div>
    </div>
  );
}

export function PauseScreen({
  score,
  distance,
  onResume,
  onRestart,
  onQuit,
}: {
  score: number;
  distance: number;
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-dusk-950/45 p-3 backdrop-blur-[3px]">
      <div className="panel anim-pop w-full max-w-[340px] rounded-[26px] p-6 text-center">
        <div className="text-4xl">⏸️</div>
        <h2 className="mt-1 font-display text-3xl font-extrabold text-white text-outline">PAUSED</h2>
        <p className="mt-1 text-xs font-semibold text-white/60">
          {fmt(score)} pts • {distance} m this run
        </p>
        <div className="mt-5 flex flex-col gap-2">
          <Btn variant="sun" size="lg" onClick={onResume}>
            ▶ RESUME
          </Btn>
          <div className="flex gap-2">
            <Btn onClick={onRestart} className="flex-1">
              ↻ RESTART
            </Btn>
            <Btn onClick={onQuit} className="flex-1">
              ⌂ MENU
            </Btn>
          </div>
        </div>
        <p className="mt-3 text-[10px] font-semibold uppercase tracking-widest text-white/35">
          press P or ESC to resume
        </p>
      </div>
    </div>
  );
}

export function GameOverScreen({
  result,
  scores,
  isBest,
  newDate,
  onRetry,
  onMenu,
}: {
  result: RunResult;
  scores: ScoreEntry[];
  isBest: boolean;
  newDate?: number;
  onRetry: () => void;
  onMenu: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-dusk-950/50 p-3 backdrop-blur-[3px]">
      <div className="panel anim-pop w-full max-w-[420px] rounded-[26px] p-5 sm:p-6">
        <div className="text-center">
          <div className="text-5xl drop-shadow-[0_6px_0_rgba(0,0,0,0.35)]">{result.causeIcon}</div>
          <h2 className="font-display text-3xl font-extrabold text-white text-outline sm:text-4xl">
            {isBest ? "NEW RECORD!" : result.cause}
          </h2>
          <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-sunset-200/70">
            {result.cause}
          </p>
        </div>

        <div className="mt-4 rounded-2xl bg-black/30 p-4 text-center">
          <div className="text-[10px] font-extrabold uppercase tracking-[0.22em] text-white/50">Final score</div>
          <div className="font-display text-5xl font-extrabold leading-none text-amber-300 text-outline">
            {fmt(result.score)}
          </div>
          <div className="mt-3 grid grid-cols-4 gap-1 text-white/80">
            <div>
              <div className="font-display text-lg">{result.distance}m</div>
              <div className="text-[9px] font-bold uppercase tracking-wider text-white/40">distance</div>
            </div>
            <div>
              <div className="font-display text-lg">🪙{result.coins}</div>
              <div className="text-[9px] font-bold uppercase tracking-wider text-white/40">coins</div>
            </div>
            <div>
              <div className="font-display text-lg">{result.flips}</div>
              <div className="text-[9px] font-bold uppercase tracking-wider text-white/40">flips</div>
            </div>
            <div>
              <div className="font-display text-lg">{result.airTime}s</div>
              <div className="text-[9px] font-bold uppercase tracking-wider text-white/40">air</div>
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-col gap-2">
          <div className="anim-ring rounded-3xl">
            <Btn variant="sun" size="lg" onClick={onRetry} className="w-full">
              ↻ RETRY INSTANTLY
            </Btn>
          </div>
          <Btn onClick={onMenu} className="w-full">
            ⌂ MAIN MENU
          </Btn>
        </div>

        <div className="mt-4">
          <h3 className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.22em] text-white/45">
            Hall of climb
          </h3>
          <ScoreTable scores={scores} highlight={newDate} />
        </div>
        <p className="mt-3 text-center text-[10px] font-semibold uppercase tracking-widest text-white/35">
          press R / ENTER to retry
        </p>
      </div>
    </div>
  );
}
