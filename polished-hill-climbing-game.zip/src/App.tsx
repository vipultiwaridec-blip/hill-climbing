import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Hud } from "@/components/Hud";
import { GameOverScreen, PauseScreen, StartScreen } from "@/components/Screens";
import { sfx } from "@/game/audio";
import { type GameState, HillGame, type HudState, type RunResult } from "@/game/engine";
import {
  bestScore,
  loadMuted,
  loadScores,
  saveMuted,
  saveScore,
  type ScoreEntry,
} from "@/game/storage";

const EMPTY_HUD: HudState = {
  score: 0,
  coins: 0,
  fuel: 100,
  boost: 45,
  speed: 0,
  distance: 0,
  combo: 1,
  flips: 0,
  airTime: 0,
  boosting: false,
  state: "menu",
};

interface Pedal {
  gas: boolean;
  brake: boolean;
  boost: boolean;
  jump: boolean;
}

const noInput = (): Pedal => ({ gas: false, brake: false, boost: false, jump: false });

function TouchControls({
  pedal,
  boostBtn,
  jumpBtn,
}: {
  pedal: Pedal;
  boostBtn: React.RefObject<HTMLDivElement | null>;
  jumpBtn: React.RefObject<HTMLDivElement | null>;
}) {
  const pad = (active: boolean, extra: string) =>
    `flex items-center justify-center rounded-3xl border-2 text-center font-display font-extrabold transition-all duration-100 ${
      active
        ? "scale-95 border-white/70 bg-white/25 text-white shadow-[0_0_24px_rgba(255,180,90,0.55)]"
        : "border-white/25 bg-black/30 text-white/60"
    } ${extra}`;
  const circle = (active: boolean, tone: "amber" | "sky") =>
    `pointer-events-auto flex h-[74px] w-[74px] shrink-0 flex-col items-center justify-center rounded-full border-2 transition-all duration-100 ${
      active
        ? tone === "amber"
          ? "scale-95 border-amber-200 bg-gradient-to-b from-amber-300 to-orange-500 text-dusk-950 shadow-[0_0_30px_rgba(255,140,40,0.85)]"
          : "scale-95 border-sky-100 bg-gradient-to-b from-sky-300 to-cyan-500 text-dusk-950 shadow-[0_0_30px_rgba(90,200,255,0.85)]"
        : tone === "amber"
          ? "border-orange-200/40 bg-black/40 text-orange-100/80"
          : "border-sky-200/40 bg-black/40 text-sky-100/80"
    }`;
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 select-none pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-end justify-between gap-2 p-2.5 sm:p-4">
        <div className="flex flex-col items-center gap-2">
          <div ref={jumpBtn} className={circle(pedal.jump, "sky")}>
            <span className="text-2xl leading-none">⤒</span>
            <span className="font-display text-[10px] font-extrabold tracking-wider">JUMP</span>
          </div>
          <div className={`${pad(pedal.brake, "h-[74px] w-[38vw] max-w-[190px]")}`}>
            <span className="flex flex-col items-center">
              <span className="text-2xl leading-none">◀</span>
              <span className="text-[10px] tracking-widest">BRAKE</span>
            </span>
          </div>
        </div>
        <div className="flex flex-col items-center gap-2">
          <div ref={boostBtn} className={circle(pedal.boost, "amber")}>
            <span className="text-2xl leading-none">🔥</span>
            <span className="font-display text-[10px] font-extrabold tracking-wider">NITRO</span>
          </div>
          <div className={`${pad(pedal.gas, "h-[74px] w-[38vw] max-w-[190px]")}`}>
            <span className="flex flex-col items-center">
              <span className="text-2xl leading-none">▶</span>
              <span className="text-[10px] tracking-widest">GAS</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const boostBtnRef = useRef<HTMLDivElement | null>(null);
  const jumpBtnRef = useRef<HTMLDivElement | null>(null);
  const gameRef = useRef<HillGame | null>(null);

  const [gameState, setGameState] = useState<GameState>("menu");
  const [hud, setHud] = useState<HudState>(EMPTY_HUD);
  const [result, setResult] = useState<RunResult | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [best, setBest] = useState<number>(() => bestScore());
  const [muted, setMuted] = useState<boolean>(() => loadMuted());
  const [isTouch, setIsTouch] = useState(false);
  const [pedal, setPedal] = useState<Pedal>(() => noInput());
  const [newDate, setNewDate] = useState<number | undefined>(undefined);
  const [isBest, setIsBest] = useState(false);

  const keyInput = useRef<Pedal>(noInput());
  const touchInput = useRef<Pedal>(noInput());
  const pointers = useRef(new Map<number, Pedal>());
  const bestRef = useRef(best);
  bestRef.current = best;
  const mutedRef = useRef(muted);
  mutedRef.current = muted;

  const applyInput = useCallback(() => {
    const g = gameRef.current;
    const k = keyInput.current;
    const t = touchInput.current;
    const next: Pedal = {
      gas: k.gas || t.gas,
      brake: k.brake || t.brake,
      boost: k.boost || t.boost,
      jump: k.jump || t.jump,
    };
    if (g) {
      g.input.gas = next.gas;
      g.input.brake = next.brake;
      g.input.boost = next.boost;
      g.input.jump = next.jump;
    }
    setPedal((p) =>
      p.gas === next.gas && p.brake === next.brake && p.boost === next.boost && p.jump === next.jump ? p : next
    );
  }, []);

  const clearInputs = useCallback(() => {
    pointers.current.clear();
    keyInput.current = noInput();
    touchInput.current = noInput();
    applyInput();
  }, [applyInput]);

  /* ---------------- engine bootstrap ---------------- */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new HillGame(canvas, {
      onHud: (h) => setHud(h),
      onState: (s) => setGameState(s),
      onGameOver: (r) => {
        const prevBest = bestRef.current;
        const entry: ScoreEntry = {
          score: r.score,
          distance: r.distance,
          coins: r.coins,
          flips: r.flips,
          date: Date.now(),
        };
        const list = saveScore(entry);
        setScores(list);
        setBest(list.length ? list[0].score : entry.score);
        setNewDate(entry.date);
        setIsBest(prevBest > 0 ? r.score > prevBest : r.score > 100);
        setResult(r);
      },
    });
    gameRef.current = game;
    sfx.setMuted(mutedRef.current);
    game.mount();

    const onResize = () => {
      game.resize();
      applyInput();
    };
    const onHidden = () => {
      if (document.hidden) game.pause();
    };
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    document.addEventListener("visibilitychange", onHidden);
    window.addEventListener("blur", onHidden);
    return () => {
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
      document.removeEventListener("visibilitychange", onHidden);
      window.removeEventListener("blur", onHidden);
      game.unmount();
      gameRef.current = null;
    };
  }, [applyInput]);

  useEffect(() => {
    setIsTouch(
      typeof window !== "undefined" &&
        ("ontouchstart" in window || (navigator.maxTouchPoints ?? 0) > 0 || window.matchMedia("(pointer: coarse)").matches)
    );
  }, []);

  useEffect(() => {
    if (gameRef.current) gameRef.current.best = best;
  }, [best]);

  useEffect(() => {
    sfx.setMuted(muted);
    saveMuted(muted);
  }, [muted]);

  /* ---------------- actions ---------------- */
  const startRun = useCallback(() => {
    sfx.resume();
    sfx.uiClick();
    clearInputs();
    gameRef.current?.play();
  }, [clearInputs]);

  const toMenu = useCallback(() => {
    sfx.uiClick();
    clearInputs();
    const g = gameRef.current;
    if (!g) return;
    g.resetRun(false);
    g.setState("menu");
  }, [clearInputs]);

  const togglePause = useCallback(() => {
    sfx.resume();
    gameRef.current?.togglePause();
  }, []);

  /* ---------------- keyboard ---------------- */
  useEffect(() => {
    const mapControl = (e: KeyboardEvent): keyof Pedal | null => {
      switch (e.code) {
        case "ArrowRight":
        case "KeyD":
        case "ArrowUp":
        case "KeyW":
          return "gas";
        case "ArrowLeft":
        case "KeyA":
        case "ArrowDown":
        case "KeyS":
          return "brake";
        case "Space":
        case "KeyX":
        case "KeyJ":
          return "jump";
        case "ShiftLeft":
        case "ShiftRight":
          return "boost";
        default:
          return null;
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      const g = gameRef.current;
      if (!g) return;
      sfx.resume();
      const ctrl = mapControl(e);
      if (ctrl) {
        e.preventDefault();
        if (g.state === "menu" || g.state === "gameover") {
          if (ctrl === "boost" || ctrl === "gas" || ctrl === "jump") startRun();
          return;
        }
        if (!keyInput.current[ctrl]) {
          keyInput.current[ctrl] = true;
          applyInput();
        }
        return;
      }
      if (e.code === "KeyP" || e.code === "Escape") {
        e.preventDefault();
        if (g.state === "playing") g.pause();
        else if (g.state === "paused") g.resume();
        return;
      }
      if (e.code === "KeyM") {
        setMuted((m) => !m);
        return;
      }
      if (e.code === "Enter" || e.code === "NumpadEnter" || e.code === "KeyR" || e.code === "Space") {
        if (g.state === "gameover") {
          e.preventDefault();
          startRun();
        } else if (g.state === "menu") {
          e.preventDefault();
          startRun();
        } else if (e.code === "KeyR" && g.state === "paused") {
          startRun();
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const ctrl = mapControl(e);
      if (!ctrl) return;
      e.preventDefault();
      if (keyInput.current[ctrl]) {
        keyInput.current[ctrl] = false;
        applyInput();
      }
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, [applyInput, startRun]);

  /* ---------------- pointer / touch ---------------- */
  const hits = useCallback((el: HTMLElement | null, x: number, y: number, pad: number) => {
    if (!el) return false;
    const b = el.getBoundingClientRect();
    return x > b.left - pad && x < b.right + pad && y > b.top - pad && y < b.bottom + pad;
  }, []);

  const classify = useCallback(
    (clientX: number, clientY: number): Pedal => {
      const wrap = wrapRef.current;
      if (!wrap) return noInput();
      const r = wrap.getBoundingClientRect();
      const gas = clientX - r.left > r.width * 0.5;
      return {
        gas,
        brake: !gas,
        boost: hits(boostBtnRef.current, clientX, clientY, 16),
        jump: hits(jumpBtnRef.current, clientX, clientY, 16),
      };
    },
    [hits]
  );

  const syncTouch = useCallback(() => {
    const list = [...pointers.current.values()];
    touchInput.current = {
      gas: list.some((p) => p.gas),
      brake: list.some((p) => p.brake),
      boost: list.some((p) => p.boost),
      jump: list.some((p) => p.jump),
    };
    applyInput();
  }, [applyInput]);

  const onPointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const g = gameRef.current;
      sfx.resume();
      if (!g || g.state !== "playing" || g.dead) return;
      if ((e.target as HTMLElement | null)?.closest("button")) return;
      pointers.current.set(e.pointerId, classify(e.clientX, e.clientY));
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
      syncTouch();
    },
    [classify, syncTouch]
  );

  const onPointerMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if (!pointers.current.has(e.pointerId)) return;
      const next = classify(e.clientX, e.clientY);
      const cur = pointers.current.get(e.pointerId)!;
      if (cur.gas !== next.gas || cur.boost !== next.boost || cur.brake !== next.brake) {
        pointers.current.set(e.pointerId, next);
        syncTouch();
      }
    },
    [classify, syncTouch]
  );

  const onPointerUp = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if (!pointers.current.has(e.pointerId)) return;
      pointers.current.delete(e.pointerId);
      syncTouch();
    },
    [syncTouch]
  );

  /* clear held inputs whenever the run state changes */
  useEffect(() => {
    clearInputs();
  }, [gameState, clearInputs]);

  const showHud = gameState === "playing" || gameState === "paused" || gameState === "gameover";
  const controlsVisible = useMemo(() => isTouch && gameState === "playing", [isTouch, gameState]);

  return (
    <div
      ref={wrapRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      onContextMenu={(e) => e.preventDefault()}
      className="no-select relative h-full w-full touch-none overflow-hidden bg-dusk-950"
      style={{ WebkitUserSelect: "none" }}
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {showHud && (
        <Hud
          hud={hud}
          best={best}
          muted={muted}
          canPause={gameState === "playing"}
          isTouch={isTouch}
          onPause={togglePause}
          onToggleMute={() => {
            sfx.resume();
            setMuted((m) => !m);
          }}
        />
      )}

      {controlsVisible && <TouchControls pedal={pedal} boostBtn={boostBtnRef} jumpBtn={jumpBtnRef} />}

      {gameState === "menu" && (
        <StartScreen best={best} scores={scores} isTouch={isTouch} onPlay={startRun} />
      )}

      {gameState === "paused" && (
        <PauseScreen
          score={hud.score}
          distance={hud.distance}
          onResume={togglePause}
          onRestart={startRun}
          onQuit={toMenu}
        />
      )}

      {gameState === "gameover" && result && (
        <GameOverScreen
          result={result}
          scores={scores}
          isBest={isBest}
          newDate={newDate}
          onRetry={startRun}
          onMenu={toMenu}
        />
      )}
    </div>
  );
}
